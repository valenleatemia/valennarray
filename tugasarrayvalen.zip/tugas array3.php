<?php

$nila

i = readline("Masukkan nilai ujian: ");


if ($nilai >= 70) {

    echo "Siswa lulus dengan nilai $nilai.";

} else {

    if ($nilai >= 40) {

    echo "Siswa tidak lulus dengan nilai $nilai.";

}

?>